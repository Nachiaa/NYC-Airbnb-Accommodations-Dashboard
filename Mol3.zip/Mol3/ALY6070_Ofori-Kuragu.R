

library(shiny)

install.packages("spreadr")
library(spreadr)
library(ggplot2)
library(dplyr)
library(plotly)
install.packages("tidyr")
library(tidyr)

# Assume you have loaded your data into two data frames: vaccinations_df and vaccinations_by_manufacturer_df
vaccinations_by_manufacturer <- read.csv("country_vaccinations_by_manufacturer.csv")
country_vaccinations <- read.csv("country_vaccinations.csv")

vaccinations_by_manufacturer <- na.omit(vaccinations_by_manufacturer)
country_vaccinations <- na.omit(country_vaccinations)

summary(vaccinations_by_manufacturer)
summary(country_vaccinations)

names(country_vaccinations)
names(vaccinations_by_manufacturer)

unique_vaccines <- unique(vaccinations_by_manufacturer$vaccine)
unique_vaccines





#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    https://shiny.posit.co/
#



# Define server logic
server <- function(input, output) {
  
  # Vaccination progress line chart
  output$progressPlot <- renderPlot({
    filtered_data <- country_vaccinations %>%
      filter(country == input$country) %>%
      mutate(Date = as.Date(date, format = "%Y-%m-%d")) %>%  # Make sure date is in Date format
      group_by(country)  # Grouping by country
    
    # Now plotting with the group aesthetic set
    ggplot(filtered_data, aes(x = Date, y = total_vaccinations, group = country)) +
      geom_line() +
      labs(title = paste("Vaccination Progress in", input$country),
           x = "Date", y = "Total Vaccinations")
  })
  
  # Manufacturer distribution line chart
  output$manufacturerPlot <- renderPlot({
    # First, summarize the total vaccinations for each location
    total_by_location <- vaccinations_by_manufacturer %>%
      filter(vaccine == input$vaccine) %>%
      group_by(location) %>%
      summarise(total_vaccinations = sum(total_vaccinations, na.rm = TRUE), .groups = 'drop') %>%
      arrange(desc(total_vaccinations)) 
    
    # Now select the top 10 locations
    top_locations <- top_n(total_by_location, 10, total_vaccinations)
    
    # Filter the original data for only the top locations
    filtered_data <- vaccinations_by_manufacturer %>%
      filter(vaccine == input$vaccine, location %in% top_locations$location)
    
    # Then plot the data
    ggplot(filtered_data, aes(x = as.Date(date), y = total_vaccinations, color = location)) +
      geom_line() +
      labs(title = paste("Top 10 Locations: Vaccination by", input$vaccine, "over Time"), x = "Date", y = "Total Vaccinations")
  })

  # Vaccine distribution pie chart
  output$vaccinePieChart <- renderPlot({
    filtered_data <- vaccinations_by_manufacturer %>%
      group_by(vaccine) %>%
      summarise(total = sum(total_vaccinations, na.rm = TRUE)) %>%
      filter(total > 0)  # Ensuring we only include vaccines that have been used
    
    ggplot(filtered_data, aes(x = "", y = total, fill = vaccine)) +
      geom_bar(width = 1, stat = "identity") +
      coord_polar(theta = "y") +  # Convert the bar chart to a pie chart
      theme_void() +  # Remove additional chart elements for a clean pie chart look
      labs(fill = "Vaccine", title = "Vaccine Distribution")  # Update the legend title
  })


  # Daily vaccination histogram
  output$dailyVaccinationHistogram <- renderPlot({
    filtered_data <- country_vaccinations %>% 
      filter(country == input$country) %>%
      filter(!is.na(daily_vaccinations_per_million))  # Removing NA values for accurate representation
    
    ggplot(filtered_data, aes(x = daily_vaccinations_per_million)) +
      geom_histogram(binwidth = 100, fill = "blue", color = "black") +
      labs(title = paste("Daily Vaccination Rate in", input$country), x = "Daily Vaccinations per Million", y = "Frequency")
  })

  # Vaccination heatmap
  output$vaccinationHeatmap <- renderPlotly({
    heatmap_data <- country_vaccinations %>% 
      group_by(country, date) %>% 
      summarise(total_vaccinations = max(total_vaccinations, na.rm = TRUE)) %>%
      spread(country, total_vaccinations) %>%
      as.data.frame()
    
    dates <- heatmap_data$date
    heatmap_data$date <- NULL
    
    plot_ly(x = colnames(heatmap_data), y = dates, z = as.matrix(heatmap_data), type = "heatmap", colors = colorRampPalette(c("blue", "yellow", "red"))(10)) %>%
      layout(title = "Heatmap of Vaccinations Over Time by Country")
  })

  # Scatter plot for Population vs. Total Vaccinations
  output$scatterPlot <- renderPlotly({
    scatter_data <- country_vaccinations %>%
      group_by(country) %>%
      summarise(total_vaccinations = max(total_vaccinations, na.rm = TRUE),
                population = max(people_vaccinated_per_hundred * 100, na.rm = TRUE)) %>%
      filter(total_vaccinations > 0, population > 0)  # Filtering out zero or NA values
    
    plot_ly(data = scatter_data, x = ~population, y = ~total_vaccinations, type = 'scatter', mode = 'markers',
            marker = list(size = 10, color = 'rgba(152, 0, 0, .8)'), text = ~country) %>%
      layout(title = "Population vs. Total Vaccinations",
             xaxis = list(title = "Population"),
             yaxis = list(title = "Total Vaccinations"))
  })
}


# Run the application 
shinyApp(ui = ui, server = server)



